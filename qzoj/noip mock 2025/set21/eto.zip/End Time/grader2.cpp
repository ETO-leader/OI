#include <bits/stdc++.h>
std::pair<int, int> push_box(int _n);
namespace yozosoft{
    #define _rep(i, x, y) for(int i = x; i <= y; ++i)
    #define _req(i, x, y) for(int i = x; i >= y; --i)
    #define _rev(i, u) for(int i = head[u]; i; i = e[i].nxt)
    #define pb push_back
    #define fi first
    #define se second
    #define mst(f, i) memset(f, i, sizeof f)
    using namespace std;
    #ifdef ONLINE_JUDGE
    #define debug(...) 0
    #else
    #define debug(...) fprintf(stderr, __VA_ARGS__), fflush(stderr)
    #endif
    typedef long long ll;
    typedef pair<int, int> PII;
    template<typename T> inline void read(T &t){
        T x = 0, f = 1;
        char c = getchar();
        while(!isdigit(c)){
            if(c == '-') f = -f;
            c = getchar();
        }
        while(isdigit(c)) x = x * 10 + c - '0', c = getchar();
        t = x * f;
    }
    template<typename T, typename ... Args> inline void read(T &t, Args&... args){
        read(t);
        read(args...);
    }
    ll T, seed, n, m, x, y, tot, ansx, ansy;
    ll dis(ll x, ll y){
        if(x > y) swap(x, y);
        return min(y - x, x + n - y);
    }
    int Query(int x, int y){
        tot++;
        if(tot > 40){
            puts("Operations Limit Exceeded, you got 8 pts.");
            exit(0);
        }
        if(!(x >= 1 && y >= 1 && x <= n && y <= n)) return -1;
        int t = min({dis(x, y), dis(x, ansx) + 1 + dis(ansy, y), dis(x, ansy) + 1 + dis(ansx, y)});
        return t;
    }
    void solve(){
        read(T, m, seed);
        if(/*!(T >= 1 && T <= 1000) || */!(m >= 4 && m <= 1000000000)) return puts("Illegal input!"), void();
        mt19937 rnd(seed);
        function<ll(ll, ll)> getv = [&](ll l, ll r){
            return rnd() % (r - l + 1) + l;
        };
        bool ok = 1;
        while(T--){
            n = getv(4ll, m), tot = 0;
            cerr << "n = " << n << '\n';
            ansx = getv(1, n), ansy = getv(1, n);
            while(dis(ansx, ansy) <= 1) ansy = getv(1, n);
            debug("(%d,%d)\n", ansx, ansy);
            PII ans = push_box(n);
            if(min(ans.fi, ans.se) == min(ansx, ansy) && max(ans.fi, ans.se) == max(ansx, ansy)){
                continue;
            }else{
                puts("Wrong Answer, you got 72 pts.");
                exit(0);
            }
        }
        puts("Accepted, the boxes can be pushed!");
    }
}
// using yozosoft::Query;
signed main(){
    yozosoft::solve();
    return 0;
}

int Query(int a, int b){
    return yozosoft::Query(a, b);
}


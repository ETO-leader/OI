#include<bits/stdc++.h>
#define cir(i,a,b) for(auto i=a;i<b;++i)
using namespace std;
ifstream inf("c.in");
ofstream ouf("c.out");
using lint=long long;
int main(){
    ios::sync_with_stdio(false),inf.tie(nullptr);
    int T;inf>>T;
    while(T--) []{
        int n;inf>>n;
        vector<int> a(n);
        for(auto&i:a) inf>>i;
        ouf<<(n+1)/2<<'\n';
        cir(i,0,(n+1)/2) ouf<<a[i]<<' ';
        ouf<<'\n';
    }();
    return 0;
}

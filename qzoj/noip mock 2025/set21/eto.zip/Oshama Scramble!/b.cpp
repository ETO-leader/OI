#include<bits/stdc++.h>
#define cir(i,a,b) for(auto i=a;i<b;++i)
using namespace std;
ifstream inf("b.in");
ofstream ouf("b.out");
using lint=long long;
int main(){
    ios::sync_with_stdio(false),inf.tie(nullptr);
    int n,p;inf>>n>>p;
    vector<int> ls(n),rs(n);
    cir(i,0,n) inf>>ls[i]>>rs[i],--ls[i],--rs[i];
    vector<int> siz(n);
    auto dfs=[&](auto __self,int u){
        if(u<0) return 1ll;
        auto res=1ll;
        (res*=__self(__self,ls[u]))%=p;
        const auto rw=__self(__self,rs[u]);
        const auto lsz=(~ls[u])?siz[ls[u]]:0;
        const auto rsz=(~rs[u])?siz[rs[u]]:0;
        // clog<<lsz<<' '<<rsz<<'\n';
        // const auto lhash=((~ls[u])?hash[ls[u]]:0);
        // const auto rhash=((~rs[u])?hash[rs[u]]:0);
        // const auto h=('('*pw[lsz*2+rsz*2+1]+(lhash*pw[rsz*2+1])+(rhash*pw[1])+')');
        // hash[u]=h;
        // const auto lfl=((~ls[u])?fl[ls[u]]:true);
        // const auto rfl=((~rs[u])?fl[rs[u]]:true);
        // fl[u]=(lsz==rsz)&&lfl&&rfl;
        (res*=rw)%=p;
        if(lsz&&lsz==rsz) (res*=2)%=p;
        if(lsz==1&&(rsz!=1)) (res*=2)%=p;
        // if(lsz==1&&(!rsz)) (res*=2)%=p;
        // if(lsz>1&&rsz>1&&lsz==rsz&&(lfl&&rfl)) (res*=2)%=p;
        siz[u]=max(lsz,rsz)+1;
        return res;
    };
    ouf<<dfs(dfs,0)<<'\n';
    return 0;
}

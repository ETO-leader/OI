n = 100000
q = 0

print(n, q, n)

for i in range(2, n + 1):
    print(i - 1, i, 0)
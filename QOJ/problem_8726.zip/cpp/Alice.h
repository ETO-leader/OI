#include <vector>
#include <utility>
std::vector<std::pair<int,int>> Alice();
long long setN(int n);

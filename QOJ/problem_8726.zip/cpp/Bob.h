#include <vector>
#include <utility>
long long Bob(std::vector<std::pair<int,int>> V);

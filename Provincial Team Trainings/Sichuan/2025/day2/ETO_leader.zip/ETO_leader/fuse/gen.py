N = 524287

print(N)

for i in range(2, N + 1):
    print(i // 2)

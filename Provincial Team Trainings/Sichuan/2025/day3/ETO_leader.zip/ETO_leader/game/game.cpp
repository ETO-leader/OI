#include"game.h"
#include<bits/stdc++.h>
#define cir(i,a,b) for(int i=a;i<b;++i)
using namespace std;

int _n;

vector<pair<int,int>> init(vector<pair<int,int>> qwq,int n,int m,int k,int q,int qlim){
    _n=n;
    if(n>20) return qwq;
    vector<pair<int,int>> res;
    cir(i,0,n) cir(j,i+1,n) res.emplace_back(i,j);
    return res;
}

int ask(){
    cir(i,0,_n) if(play({i})==-1) return i;
    assert(false);
}


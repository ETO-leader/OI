#include<vector>
// 交互库实现的函数
int play(std::vector<int>);

// 选手实现的函数
std::vector<std::pair<int, int>> init(std::vector<std::pair<int, int>>, int, int, int, int, int);
int ask();